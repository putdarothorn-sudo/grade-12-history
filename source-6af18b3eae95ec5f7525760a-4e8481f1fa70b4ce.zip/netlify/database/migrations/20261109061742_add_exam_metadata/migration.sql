ALTER TABLE "knowledge" ADD COLUMN "category" text DEFAULT 'reference' NOT NULL;--> statement-breakpoint
ALTER TABLE "knowledge" ADD COLUMN "title" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "knowledge" ADD COLUMN "year" text DEFAULT '' NOT NULL;