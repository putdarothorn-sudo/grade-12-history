-- Restore the schema on branches whose migration ledger exists but table is missing.
-- Existing notebooks and references are preserved when the table already exists.
CREATE TABLE IF NOT EXISTS "knowledge" (
  "id" serial PRIMARY KEY,
  "notebook" text NOT NULL,
  "content" text NOT NULL,
  "created_at" timestamp DEFAULT now() NOT NULL
);
