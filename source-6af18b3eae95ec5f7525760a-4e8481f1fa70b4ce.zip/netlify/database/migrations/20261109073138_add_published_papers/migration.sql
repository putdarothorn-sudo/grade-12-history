CREATE TABLE "published_papers" (
	"id" text PRIMARY KEY,
	"year" integer NOT NULL,
	"track" text NOT NULL,
	"session" integer NOT NULL,
	"page_start" integer NOT NULL,
	"page_end" integer NOT NULL,
	"pdf_path" text NOT NULL
);
