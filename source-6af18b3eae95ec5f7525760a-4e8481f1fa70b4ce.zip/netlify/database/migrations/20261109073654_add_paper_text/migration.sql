ALTER TABLE "published_papers" ADD COLUMN "questions" text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE "published_papers" ADD COLUMN "answers" text DEFAULT '' NOT NULL;